package com.umeeds.app.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.umeeds.app.R;
import com.umeeds.app.activity.BuyMemberShipPlanActivity;
import com.umeeds.app.model.MemberShipPlanModel;

import java.util.List;


public class MemberShipPlanAdapter extends RecyclerView.Adapter<MemberShipPlanAdapter.CustomerViewHolder> {

    private FragmentActivity context;
    private List<MemberShipPlanModel.MemberShipPlanData> chatDataList;

    public MemberShipPlanAdapter(FragmentActivity context){
        this.context = context;
    }


    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.member_ship_plan_list, parent, false);
        return new CustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomerViewHolder holder, int position) {
        final MemberShipPlanModel.MemberShipPlanData customerList = chatDataList.get(position);
        holder.tv_planid.setText("Planid : "+customerList.getPlanId());
        holder.tv_plandisplayname.setText("Plan Type : "+customerList.getPlandisplayName());
        holder.tv_planamount.setText("Amount : INR "+customerList.getPlanamount());
        holder.tv_planduration.setText("Validity : "+customerList.getPlanduration()+" Days");
        holder.tv_planchatcontact.setText("Plan chat contact : "+customerList.getPlanchatcontact());
        holder.tv_plannoofcontacts.setText("Allowed Contact : "+customerList.getPlannoofcontacts());


        if (customerList.getPlandisplayName().equals("GOLDEN")){
            holder.sellerImagev.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_gold_bronze));
        }
        if (customerList.getPlandisplayName().equals("SILVER")){
            holder.sellerImagev.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_bronze));
        }
        if (customerList.getPlandisplayName().equals("BRONZE")){
            holder.sellerImagev.setImageDrawable(context.getResources().getDrawable(R.drawable.ic_revenue_pink));
        }


       /* RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.drawable.locality_logo_small)
                .error(R.drawable.locality_logo_small)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .priority(Priority.HIGH).dontAnimate()
                .dontTransform();

        Glide.with(context)
                .load(IMAGE_LOAD_USER + singleItem.getUserImage())
                .apply(options)
                .into(holder.sellerImagev);
*/

        holder.bt_upgrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, BuyMemberShipPlanActivity.class);
                intent.putExtra("planId", customerList.getPlanId());
                intent.putExtra("plan", customerList.getPlandisplayName());
                intent.putExtra("amount", customerList.getPlanamount());
                intent.putExtra("validity", customerList.getPlanduration());
                intent.putExtra("chatcontact", customerList.getPlanchatcontact());
                intent.putExtra("contact", customerList.getPlanchatcontact());
                intent.putExtra("plantype", customerList.getPlandisplayName());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return null == chatDataList ? 0 : chatDataList.size();
    }

    public void addCustomerList(List<MemberShipPlanModel.MemberShipPlanData> customerListList){
        this.chatDataList = customerListList;
        notifyDataSetChanged();
    }

    class CustomerViewHolder extends RecyclerView.ViewHolder {
        private ImageView sellerImagev;
        private TextView tv_planid;
        private TextView tv_plandisplayname;
        private TextView tv_planamount;
        private TextView tv_planduration;
        private TextView tv_plannoofcontacts,tv_planchatcontact;
        private Button bt_upgrade;

        private LinearLayout layout_item;


        CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            sellerImagev = itemView.findViewById(R.id.sellerImagev);
            tv_planid = itemView.findViewById(R.id.tv_planid);
            tv_plandisplayname = itemView.findViewById(R.id.tv_plandisplayname);
            tv_planamount = itemView.findViewById(R.id.tv_planamount);
            tv_planduration = itemView.findViewById(R.id.tv_planduration);
            tv_plannoofcontacts = itemView.findViewById(R.id.tv_plannoofcontacts);
            tv_planchatcontact = itemView.findViewById(R.id.tv_planchatcontact);
            bt_upgrade = itemView.findViewById(R.id.bt_upgrade);
            layout_item = itemView.findViewById(R.id.layout_item);

        }
    }

}