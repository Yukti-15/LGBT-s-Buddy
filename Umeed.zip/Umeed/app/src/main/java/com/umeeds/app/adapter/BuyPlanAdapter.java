package com.umeeds.app.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.umeeds.app.R;
import com.umeeds.app.model.BuyPlanModel;

import java.util.List;


public class BuyPlanAdapter extends RecyclerView.Adapter<BuyPlanAdapter.CustomerViewHolder> {

    private FragmentActivity context;
    private List<BuyPlanModel.BuyPlanData> buyPlanDataList;
    private BuyPlanClickListener buyPlanClickListener;

    public BuyPlanAdapter(FragmentActivity context,BuyPlanClickListener buyPlanClickListener){
        this.context = context;
        this.buyPlanClickListener = buyPlanClickListener;
    }
    public interface BuyPlanClickListener{
        void onEvent(BuyPlanModel.BuyPlanData buyPlanData, View view);
    }

    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.buy_plan_list, parent, false);
        return new CustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomerViewHolder holder, int position) {
        final BuyPlanModel.BuyPlanData customerList = buyPlanDataList.get(position);

        if (customerList.getOption_type().equals("CCAvenue")){
            holder.tv_buyplan.setText(customerList.getOption_type() +" (Credit Card/Debit Card/NetBanking/Paytm)");
            holder.iv_payicon.setImageDrawable(context.getDrawable(R.drawable.ccavenue_logo));
        }else {
            holder.tv_buyplan.setText(customerList.getOption_type());
            holder.iv_payicon.setImageDrawable(context.getDrawable(R.drawable.paytm));
        }

    }

    @Override
    public int getItemCount() {
        return null == buyPlanDataList ? 0 : buyPlanDataList.size();
    }

    public void addCustomerList(List<BuyPlanModel.BuyPlanData> customerListList){
        this.buyPlanDataList = customerListList;
        notifyDataSetChanged();
    }

    class CustomerViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        private TextView tv_buyplan;
              private LinearLayout layout_item;

              ImageView iv_payicon;
        CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_buyplan = itemView.findViewById(R.id.tv_buyplan);
            layout_item = itemView.findViewById(R.id.layout_item);
            iv_payicon = itemView.findViewById(R.id.iv_payicon);

            layout_item.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            buyPlanClickListener.onEvent(buyPlanDataList.get(getAdapterPosition()), v);
        }
    }

}