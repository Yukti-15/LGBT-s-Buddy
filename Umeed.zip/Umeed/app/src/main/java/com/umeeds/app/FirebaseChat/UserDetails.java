package com.umeeds.app.FirebaseChat;

public  class UserDetails {
    public static String username = "";
    public static String password = "";
    public static String chatWith = "";

}
