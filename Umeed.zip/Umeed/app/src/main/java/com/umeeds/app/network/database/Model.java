package com.umeeds.app.network.database;

public interface Model {
}
