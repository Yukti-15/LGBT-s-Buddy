package com.umeeds.app.adapter;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.umeeds.app.R;
import com.umeeds.app.activity.MoreInfoActivity;
import com.umeeds.app.model.HomeModel;
import com.umeeds.app.model.LoginModel;
import com.umeeds.app.network.database.SharedPrefsManager;
import com.umeeds.app.network.networking.ApiClient;
import com.umeeds.app.network.networking.ApiInterface;

import java.util.List;

import jp.wasabeef.glide.transformations.BlurTransformation;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.bumptech.glide.request.RequestOptions.bitmapTransform;
import static com.umeeds.app.network.networking.Constant.IMAGE_LOAD_USER;
import static com.umeeds.app.network.networking.Constant.MATRI_ID;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.CustomerViewHolder> {

    private FragmentActivity context;
    private Fragment fragment;
    private List<HomeModel.HomeData> homeDataList;
    private ApiInterface apiInterface;
    private String heartlist;

    public HomeAdapter(FragmentActivity context, Fragment fragment, List<HomeModel.HomeData> homeDataList) {
        this.context = context;
        this.fragment = fragment;
        this.homeDataList = homeDataList;
        apiInterface = ApiClient.getInterface();
    }

    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.home_list, parent, false);
        return new CustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final CustomerViewHolder holder, final int position) {
        final HomeModel.HomeData customerList = homeDataList.get(position);
        holder.name.setText(customerList.getMatriId());
        holder.tv_age.setText(customerList.getAge() + " Years");
        holder.tv_gender.setText(customerList.getGenderUser());
        final String matriId = customerList.getMatriId();
        final String sendrequest = customerList.getSendrequest();

        heartlist = customerList.getHeartlist();
        String status = customerList.getStatus();
        String profileStatus = customerList.getProfile_status();
        String verify_status = customerList.getVerify_status();


        if (verify_status.equals("0")) {
            holder.tv_verified.setText("Not Verified");
            holder.iv_verified.setImageDrawable(context.getDrawable(R.drawable.ic_check_circle_black_24dp));
            DrawableCompat.setTint(holder.iv_verified.getDrawable(), ContextCompat.getColor(context, R.color.black));
        } else {
            holder.tv_verified.setText("Verified");
            holder.iv_verified.setImageDrawable(context.getDrawable(R.drawable.ic_check_circle_black_24dp));
            DrawableCompat.setTint(holder.iv_verified.getDrawable(), ContextCompat.getColor(context, R.color.blue));
        }

        if (heartlist.equals("1")) {
            holder.likeBtn.setVisibility(View.VISIBLE);
            holder.unlikeBtn.setVisibility(View.GONE);
        } else {
            holder.likeBtn.setVisibility(View.GONE);
            holder.unlikeBtn.setVisibility(View.VISIBLE);
        }

        RequestOptions options = new RequestOptions()
                .centerCrop()
                .placeholder(R.drawable.no_photo)
                .error(R.drawable.no_photo)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .priority(Priority.HIGH).dontAnimate()
                .dontTransform();

        if (profileStatus.equals("show")) {
            Glide.with(context)
                    .load(IMAGE_LOAD_USER + customerList.getPhoto1())
                    .apply(options)
                    .into(holder.user_image);
        } else {
            Glide.with(context)
                    .load(IMAGE_LOAD_USER + customerList.getPhoto1())
                    .apply(bitmapTransform(new BlurTransformation(25)))
                    .into(holder.user_image);
        }

        if (customerList.getSendrequest().equals("0")) {
            holder.bt_request.setText("Send request");

        } else {
            holder.bt_request.setText("Requested");
        }

        holder.bt_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (customerList.getSendrequest().equals("0")) {
                    holder.bt_request.setText("Requested");
                    // ((MainFragment) fragment).sendRequest(matriId, SharedPrefsManager.getInstance().getString(MATRI_ID));
                    sendRequest(matriId, SharedPrefsManager.getInstance().getString(MATRI_ID), position);
                }
            }
        });

        holder.likeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // ((MainFragment) fragment).sendheartlist(matriId, SharedPrefsManager.getInstance().getString(MATRI_ID), "1");
                sendheartlist(matriId, SharedPrefsManager.getInstance().getString(MATRI_ID), "1", position);
                //  homeDataList.get(position).setHeartlist("1");
                //  notifyItemChanged(position);
                holder.likeBtn.setVisibility(View.GONE);
                holder.unlikeBtn.setVisibility(View.VISIBLE);
                // holder.iv_heart.setImageDrawable(context.getDrawable(R.drawable.ic_favorite_heart_pink));
            }
        });

        holder.unlikeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //   ((MainFragment) fragment).sendheartlist(matriId, SharedPrefsManager.getInstance().getString(MATRI_ID), "1");
                sendheartlist(matriId, SharedPrefsManager.getInstance().getString(MATRI_ID), "1", position);
                // homeDataList.get(position).setHeartlist("0");
                //notifyItemChanged(position);
                holder.likeBtn.setVisibility(View.VISIBLE);
                holder.unlikeBtn.setVisibility(View.GONE);
                // holder.iv_heart.setImageDrawable(context.getDrawable(R.drawable.ic_favorite_heart_pink));
            }
        });

        holder.bt_moreInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, MoreInfoActivity.class);
                intent.putExtra("martId", customerList.getMatriId());
             //   intent.putExtra("blur_status", profileStatus);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return null == homeDataList ? 0 : homeDataList.size();
    }

    /* public void add(RecentlyJoinedListModel.RecentlyJoinedListingModel response) {
            itemsList.add(response);
           // Collections.reverse(itemsList);
            notifyDataSetChanged();
        }
    */
    public void addCustomerList(HomeModel.HomeData homeListList) {
        // this.homeDataList = homeListList;
        homeDataList.add(homeListList);
        notifyDataSetChanged();
    }

    public void addAll(List<HomeModel.HomeData> postItems) {
        for (int i = 0; i < postItems.size(); i++) {
            addCustomerList(postItems.get(i));
        }
    }


    class CustomerViewHolder extends RecyclerView.ViewHolder {
        private ImageView user_image, iv_verified;
        private TextView name;
        private TextView tv_age, tv_verified, tv_gender;
        private LinearLayout layout_item;
        private Button bt_request, bt_moreInfo;
        private ImageView likeBtn, unlikeBtn;

        RelativeLayout rv_image;

        CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            user_image = itemView.findViewById(R.id.user_image);
            // iv_heart = itemView.findViewById(R.id.iv_heart);
            unlikeBtn = itemView.findViewById(R.id.iv_unlike);
            likeBtn = itemView.findViewById(R.id.iv_like);

            name = itemView.findViewById(R.id.name);
            tv_age = itemView.findViewById(R.id.tv_age);
            tv_gender = itemView.findViewById(R.id.tv_gender);
            layout_item = itemView.findViewById(R.id.layout_item);
            bt_request = itemView.findViewById(R.id.bt_request);
            bt_moreInfo = itemView.findViewById(R.id.bt_moreInfo);
            tv_verified = itemView.findViewById(R.id.tv_verified);
            iv_verified = itemView.findViewById(R.id.iv_verified);
            rv_image = itemView.findViewById(R.id.rv_image);
        }
    }


    public void sendheartlist(String matriId, String loginmatriid, String status, final int position) {
        apiInterface.sendheartlist(matriId, loginmatriid, status).enqueue(new Callback<LoginModel>() {
            @Override
            public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {
                if (response.isSuccessful()) {
                    LoginModel homeModel = response.body();
                    if (homeModel != null) {
                        boolean respnse = homeModel.isResponse();
                        if (respnse) {
                            if (homeDataList.get(position).getHeartlist().equals("1")) {
                                homeDataList.get(position).setHeartlist("0");
                                notifyItemChanged(position);
                            } else {
                                homeDataList.get(position).setHeartlist("1");
                                notifyItemChanged(position);
                            }
                        } else {
                            //   Toast.makeText(getContext(),"UnLike",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginModel> call, Throwable t) {
                Toast.makeText(context, "something is wrong", Toast.LENGTH_LONG).show();
                //     progress.cancleDialog();
            }
        });
    }


    public void sendRequest(String matriId, String loginmatriid, final int position) {
        apiInterface.sendFriendRequest(matriId, loginmatriid).enqueue(new Callback<LoginModel>() {
            @Override
            public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {
                if (response.isSuccessful()) {
                    LoginModel homeModel = response.body();
                    if (homeModel != null) {
                        boolean respnse = homeModel.isResponse();
                        if (respnse) {
                            Toast.makeText(context, "Sent request", Toast.LENGTH_SHORT).show();
                            /*if (homeDataList.get(position).getHeartlist().equals("1")){
                                homeDataList.get(position).setHeartlist("0");
                                notifyItemChanged(position);
                            }else {
                                homeDataList.get(position).setHeartlist("1");
                                notifyItemChanged(position);
                            }*/
                            homeDataList.get(position).setSendrequest("1");
                            notifyItemChanged(position);

                        } else {
                            //  Toast.makeText(getContext(),"Already sent request",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<LoginModel> call, Throwable t) {
                Toast.makeText(context, "something is wrong", Toast.LENGTH_LONG).show();
            }
        });

    }


}